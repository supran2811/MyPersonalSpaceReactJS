import React, { Component } from 'react';

class Course extends Component {
    state ={
        title : "",
        id:""
    }

    componentDidMount(){
        console.log("Inside course",this.props.location.search);
        let search = ""+this.props.location.search.substr(1);
        console.log(search);
        const params = new URLSearchParams(search);
        console.log(params);
        console.log("params",params.get('title'));
        const newId  = this.props.match.params.id;
        if(this.state.id !== newId){
            this.setState({title : params.get('title'),id:newId});
        }
    }

    componentDidUpdate(){
        console.log("Inside course",this.props.location.search);
        let search = ""+this.props.location.search.substr(1);
        console.log(search);
        const params = new URLSearchParams(search);
        console.log(params);
        console.log("params",params.get('title'));

        const newId  = this.props.match.params.id;
        if(this.state.id !== newId){
            this.setState({title : params.get('title'),id:newId});
        }
    }

    render () {
        
        return (
            <div>
                <h1>{this.state.title}</h1>
                <p>You selected the Course with ID: {this.props.match.params.id}</p>
            </div>
        );
    }
}

export default Course;