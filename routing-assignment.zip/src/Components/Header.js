import React from 'react';
import {NavLink} from 'react-router-dom';
const header = () => (
    <div>
        <ul>
            <li><NavLink to="/users">Users</NavLink></li>
            <li><NavLink to="/courses">Courses</NavLink></li>
        </ul>
    </div>
);

export default header;