import React from 'react';

const ValidationComponent = (props) => {

    const isLong = props.length >= 5;
    
    return (
        <div>
       {
           isLong ? <p> Text is long enoungh</p>:<p>Text is too short</p>
       }
       </div>
    );
}

export default ValidationComponent;