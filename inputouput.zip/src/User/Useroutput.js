import React from 'react';
import './Useroutput.css'

const Useroutput = (props) => {
        
        return (
            <div className = "output">
            <p>My name is {props.username}</p>
            <p>My age is 34</p>
            </div>
        );
}

export default Useroutput;