import React from 'react';

const Userinput = (props) => {
    const style = {
        width  : "20%",
        margin : "10px auto",
        border : "1px solid #eee",
        backgroundColor : "white",
        padding: "10px 2px 10px 2px"
        
    }
     return (
         <div>
             <input style={style} type="text" onChange = {props.onChangeHandler} value = {props.value}/>
         </div>
     );
}

export default Userinput;